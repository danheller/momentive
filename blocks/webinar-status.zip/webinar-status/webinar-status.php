<?php
/**
 * Webinar Status Label block.
 *
 * Outputs "Upcoming" or "On-Demand" using the global .top-label style (the same
 * label treatment press articles use for their category). Reads the computed
 * status so it flips in lockstep with the schedule block and form resolver.
 */

$post_id = get_the_ID();

$status = function_exists( 'momentive_webinar_status' )
	? momentive_webinar_status( $post_id )
	: ( get_field( 'webinar_type', $post_id ) ?: 'upcoming' );

$label = ( 'on-demand' === $status )
	? __( 'On-Demand Webinar', 'momentive' )
	: __( 'Upcoming Webinar', 'momentive' );

printf(
	'<p class="top-label is-webinar-%s">%s</p>',
	esc_attr( $status ),
	esc_html( $label )
);
